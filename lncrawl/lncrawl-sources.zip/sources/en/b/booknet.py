# -*- coding: utf-8 -*-
import logging
from urllib.parse import quote_plus

from lncrawl.core import Chapter, LegacyCrawler, Volume

logger = logging.getLogger(__name__)
search_url = "https://booknet.com/en/search?q=%s"
get_chapter_url = "https://booknet.com/reader/get-page"


class LitnetCrawler(LegacyCrawler):
    base_url = [
        "https://booknet.com/",
    ]

    def initialize(self):
        self.scraper.origin = "https://booknet.com/"

    def search_novel(self, query):
        query = quote_plus(query.lower())
        soup = self.get_soup(search_url % query)

        results = []
        for div in soup.select(".book-item"):
            a = div.select_one(".book-title a")
            author = div.select_one(".author-wr a.author").text.strip()
            views = div.select_one("span.count-views").text.strip()
            favourites = div.select_one("span.count-favourites").text.strip()
            results.append(
                {
                    "title": a.text.strip(),
                    "url": self.absolute_url(a["href"]),
                    "info": "Author: %s | %s views | %s favorites" % (author, views, favourites),
                }
            )

        return results

    def read_novel_info(self):
        logger.debug("Visiting %s", self.novel_url)
        soup = self.get_soup(self.novel_url)

        self.csrf_token = soup.select_one('meta[name="csrf-token"]')["content"]
        self.csrf_param = soup.select_one('meta[name="csrf-param"]')["content"]
        logger.info("%s: %s", self.csrf_param, self.csrf_token)

        possible_title = soup.select_one("h1.roboto")
        assert possible_title, "No novel title"
        self.novel_title = possible_title.text.strip()
        logger.info("Novel title: %s", self.novel_title)

        img_src = soup.select_one(".book-view-cover img")
        if not img_src:
            img_src = soup.select_one(".book-cover img")
        if img_src:
            self.novel_cover = self.absolute_url(img_src["src"])
        logger.info("Novel cover: %s", self.novel_cover)

        author = soup.select_one(".book-view-info a.author")
        if not author:
            author = soup.select_one(".book-head-content a.book-author")
        if author:
            self.novel_author = author.text.strip()
        logger.info("Novel author: %s", self.novel_author)

        container = soup.select_one("select[name='chapter']")
        if container is None:
            chapters = soup.select(".collapsible-body a.collection-item")
        else:
            chapters = [a for a in container.find_all("option") if a["value"]]

        volumes = set([])
        for a in chapters:
            chap_id = len(self.chapters) + 1
            vol_id = len(self.chapters) // 100 + 1
            volumes.add(vol_id)

            abs_url = self.last_url.replace("/en/book/", "/en/reader/")
            chap_url = abs_url + ("?c=%s" % a.attrs["value"])
            self.chapters.append(
                Chapter(
                    id=chap_id,
                    volume=1,
                    url=chap_url,
                    chapter_id=a.attrs["value"],
                )
            )

        self.volumes = [Volume(id=x) for x in volumes]

    def download_chapter_body(self, chapter):
        data = self._get_chapter_page(chapter)
        chapter["title"] = data["chapterTitle"]
        content = data["data"]

        for page in range(2, data["totalPages"] + 1):
            data = self._get_chapter_page(chapter, page)
            content += data["data"]

        return content

    def _get_chapter_page(self, chapter, page=1):
        return self.post_json(
            get_chapter_url,
            data={
                "chapterId": int(chapter["chapter_id"]),
                "page": page,
                self.csrf_param: self.csrf_token,
            },
            headers={
                "X-CSRF-Token": self.csrf_token,
                "Content-Type": "application/x-www-form-urlencoded; charset=UTF-8",
            },
        )
